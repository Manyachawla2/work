import s from "./SpinnerLoading.module.scss";
const SpinnerLoading = () => <div className={s.loader} />;
export default SpinnerLoading;
